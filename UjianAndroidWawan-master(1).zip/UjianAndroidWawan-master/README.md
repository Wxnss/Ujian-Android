# APLIKASI ANDROID
###### Aplikasi android sederhana untuk menampilkan inputan data kedalam listview

### Dibuat Oleh :
##### Ian Alan Natanael
### NIM
##### G.131.22.0063